#include<stdio.h>
int main(){
    int fd1[2];
    int fd2[2];
    char input_string[] = "first program using vim";
    printf("%s\n",input_string);
}

